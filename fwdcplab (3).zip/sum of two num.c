#include<stdio.h>
int main()
{
	int num1 , num2, sum;
	printf("Enter two numbers:");
	scanf("%d %d",&num1,&num2);
	sum=num1+num2;
	printf("sum of two numbers: %d",sum);
	return 0;
}
