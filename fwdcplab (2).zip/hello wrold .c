#include<stdio.h>
int main ()
{
 printf("Hello Wrold");
return 0 ; 
}
